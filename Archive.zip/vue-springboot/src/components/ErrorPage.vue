<template>
    <h1>Error Page!</h1>
</template>

<script>
    export default {
        name: "ErrorPage"
    }
</script>

<style scoped>

</style>